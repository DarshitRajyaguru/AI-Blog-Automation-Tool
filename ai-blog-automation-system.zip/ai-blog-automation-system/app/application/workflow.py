from __future__ import annotations

from datetime import datetime

from sqlalchemy.orm import Session

from app.ai_engine.content_service import AIContentService
from app.application.content_assembly import ContentAssemblyService
from app.application.dto import AutomationRequest
from app.application.duplicate_prevention import DuplicatePreventionService
from app.application.publication_service import PublicationService
from app.config import get_settings
from app.database.models import (
    AutomationJobStatus,
    BlogPost,
    GeneratedImage,
    ImageKind,
    KeywordStatus,
    PostLifecycleStatus,
)
from app.image_engine.service import ImageService
from app.repositories.blog_post_repository import BlogPostRepository
from app.repositories.job_repository import JobRepository
from app.repositories.keyword_repository import KeywordRepository
from app.repositories.publication_log_repository import PublicationLogRepository
from app.repositories.website_repository import WebsiteRepository
from app.seo_engine.service import SEOService
from app.utils.hashing import sha256_text
from app.utils.html import markdown_to_html
from app.utils.text import slugify


class BlogAutomationWorkflow:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.settings = get_settings()
        self.ai_service = AIContentService()
        self.seo_service = SEOService()
        self.image_service = ImageService()

        self.keyword_repository = KeywordRepository(db)
        self.blog_post_repository = BlogPostRepository(db)
        self.website_repository = WebsiteRepository(db)
        self.job_repository = JobRepository(db)
        self.publication_log_repository = PublicationLogRepository(db)

        self.duplicate_prevention = DuplicatePreventionService(
            keyword_repository=self.keyword_repository,
            blog_post_repository=self.blog_post_repository,
        )
        self.content_assembly = ContentAssemblyService()
        self.publication_service = PublicationService(
            website_repository=self.website_repository,
            publication_log_repository=self.publication_log_repository,
        )

    def process_keyword(self, request: AutomationRequest) -> BlogPost:
        keyword = self.keyword_repository.get(request.keyword_id)
        if not keyword:
            raise ValueError(f"Keyword {request.keyword_id} not found.")
        if keyword.status == KeywordStatus.COMPLETED:
            raise ValueError("Keyword already processed.")

        self.duplicate_prevention.ensure_keyword_is_available(keyword.keyword, keyword.id)

        job = self.job_repository.create_running_job(keyword.id)
        keyword.status = KeywordStatus.PROCESSING
        self.db.commit()

        try:
            generated = self.ai_service.generate_blog(keyword=keyword.keyword, word_count=request.word_count)
            self._ensure_heading_integrity(generated.headings)

            content_hash = sha256_text(generated.content_markdown)
            self.duplicate_prevention.ensure_content_hash_is_unique(content_hash)

            embedding = None
            if request.similarity_check_enabled and self.settings.embedding_similarity_enabled:
                embedding = self.ai_service.generate_embedding(generated.content_markdown)
                self.duplicate_prevention.ensure_similarity_is_safe(embedding, request.similarity_threshold)

            seo = self.seo_service.enhance(generated)
            post = self.blog_post_repository.add(
                BlogPost(
                    keyword_id=keyword.id,
                    title=generated.title,
                    slug=slugify(generated.slug or generated.title),
                    meta_title=seo["meta_title"],
                    meta_description=seo["meta_description"],
                    seo_keywords=seo["keywords"],
                    content_markdown=generated.content_markdown,
                    content_html=markdown_to_html(generated.content_markdown),
                    faq_items=[item.model_dump() for item in generated.faq],
                    outlines=[heading.model_dump() for heading in generated.headings],
                    content_hash=content_hash,
                    content_embedding=embedding,
                    readability_score=seo["readability_score"],
                    lifecycle_status=PostLifecycleStatus.GENERATED,
                    publish_status=request.post_status,
                    scheduled_for=request.scheduled_for,
                )
            )

            self._create_images(post, generated, request)
            self.db.flush()
            self.content_assembly.embed_inline_images(post, generated)
            self.db.commit()

            post = self.blog_post_repository.get_with_assets(post.id) or post
            inline_payload = self.content_assembly.build_inline_payload(list(post.images))
            self.publication_service.publish(post, request.website_ids, inline_payload)

            keyword.status = KeywordStatus.COMPLETED
            keyword.last_processed_at = datetime.utcnow()
            post.lifecycle_status = (
                PostLifecycleStatus.SCHEDULED if request.post_status == "scheduled" else PostLifecycleStatus.PUBLISHED
            )
            if request.post_status != "scheduled":
                post.published_at = datetime.utcnow()
            job.status = AutomationJobStatus.SUCCESS
            job.finished_at = datetime.utcnow()
            job.blog_post_id = post.id
            job.message = "Automation pipeline completed successfully."
            self.db.commit()
            return post
        except Exception as exc:
            keyword.status = KeywordStatus.FAILED
            job.status = AutomationJobStatus.FAILED
            job.finished_at = datetime.utcnow()
            job.message = str(exc)
            self.db.commit()
            raise

    def _create_images(self, post: BlogPost, blog, request: AutomationRequest) -> None:
        featured = self.image_service.generate_image(
            prompt=(
                f"Create a high-quality featured image for the blog post titled '{blog.title}' about {blog.keywords[0]}. "
                "Use a professional editorial style suitable for a modern business blog."
            ),
            width=request.featured_image_width,
            height=request.featured_image_height,
            alt_text=f"Featured image for {blog.title}",
        )
        self.db.add(
            GeneratedImage(
                blog_post_id=post.id,
                kind=ImageKind.FEATURED,
                prompt=featured["prompt"],
                alt_text=featured["alt_text"],
                storage_path=featured["storage_path"],
                source_url=featured["source_url"],
                mime_type=featured["mime_type"],
                width=featured["width"],
                height=featured["height"],
                position_index=0,
            )
        )

        for index, heading in enumerate(blog.headings[1 : 1 + request.inline_image_count], start=1):
            inline = self.image_service.generate_image(
                prompt=f"Editorial illustration for section '{heading.title}' in a blog about {blog.keywords[0]}",
                width=1024,
                height=1024,
                alt_text=f"Illustration for {heading.title}",
            )
            self.db.add(
                GeneratedImage(
                    blog_post_id=post.id,
                    kind=ImageKind.INLINE,
                    prompt=inline["prompt"],
                    alt_text=inline["alt_text"],
                    storage_path=inline["storage_path"],
                    source_url=inline["source_url"],
                    mime_type=inline["mime_type"],
                    width=inline["width"],
                    height=inline["height"],
                    position_index=index,
                )
            )

    def _ensure_heading_integrity(self, headings) -> None:
        if not headings:
            raise ValueError("Generated content did not include headings.")
        if headings[0].level != "H1":
            raise ValueError("Generated content must start with an H1 heading.")
