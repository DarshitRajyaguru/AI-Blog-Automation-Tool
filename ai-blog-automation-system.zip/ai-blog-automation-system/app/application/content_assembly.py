from __future__ import annotations

from app.ai_engine.schemas import BlogGenerationResult
from app.database.models import BlogPost, GeneratedImage, ImageKind
from app.utils.html import markdown_to_html


class ContentAssemblyService:
    def embed_inline_images(self, post: BlogPost, generated: BlogGenerationResult) -> None:
        content = post.content_markdown
        inline_images = sorted(
            [image for image in post.images if image.kind == ImageKind.INLINE],
            key=lambda image: image.position_index,
        )
        inline_headings = generated.headings[1 : 1 + len(inline_images)]

        for heading, image in zip(inline_headings, inline_images):
            prefix = "##" if heading.level == "H2" else "###"
            heading_marker = f"{prefix} {heading.title}"
            image_marker = f'\n\n![{image.alt_text}]({image.storage_path} "{image.alt_text}")\n'
            if heading_marker in content:
                content = content.replace(heading_marker, f"{heading_marker}{image_marker}", 1)

        post.content_markdown = content
        post.content_html = markdown_to_html(content)

    def build_inline_payload(self, images: list[GeneratedImage]) -> list[dict[str, str]]:
        return [
            {"storage_path": image.storage_path, "alt_text": image.alt_text}
            for image in sorted(images, key=lambda image: image.position_index)
            if image.kind == ImageKind.INLINE and image.storage_path
        ]
