from __future__ import annotations

from app.repositories.blog_post_repository import BlogPostRepository
from app.repositories.keyword_repository import KeywordRepository
from app.utils.text import cosine_similarity


class DuplicatePreventionService:
    def __init__(
        self,
        keyword_repository: KeywordRepository,
        blog_post_repository: BlogPostRepository,
    ) -> None:
        self.keyword_repository = keyword_repository
        self.blog_post_repository = blog_post_repository

    def ensure_keyword_is_available(self, keyword: str, keyword_id: int) -> None:
        if self.keyword_repository.normalized_keyword_completed_exists(keyword, excluding_id=keyword_id):
            raise ValueError("Normalized keyword already used in a completed post.")

    def ensure_content_hash_is_unique(self, content_hash: str) -> None:
        if self.blog_post_repository.content_hash_exists(content_hash):
            raise ValueError("Generated content hash matches an existing post.")

    def ensure_similarity_is_safe(self, embedding: list[float], threshold: float) -> None:
        for post in self.blog_post_repository.posts_with_embeddings():
            similarity = cosine_similarity(embedding, post.content_embedding or [])
            if similarity >= threshold:
                raise ValueError(
                    f"Similarity threshold exceeded against existing post {post.id}: {similarity:.3f} >= {threshold:.3f}"
                )
