from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass
class AutomationRequest:
    keyword_id: int
    website_ids: list[int]
    word_count: int
    inline_image_count: int
    featured_image_width: int
    featured_image_height: int
    post_status: str
    similarity_check_enabled: bool
    similarity_threshold: float
    scheduled_for: datetime | None = None
