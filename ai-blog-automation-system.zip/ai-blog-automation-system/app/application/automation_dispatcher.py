from __future__ import annotations

from datetime import datetime

from app.config import get_settings
from app.database.models import AutomationRule, KeywordStatus
from app.repositories.keyword_repository import KeywordRepository
from app.scheduler.tasks import process_keyword_task


class AutomationDispatcher:
    def __init__(self, keyword_repository: KeywordRepository) -> None:
        self.keyword_repository = keyword_repository
        self.settings = get_settings()

    def ensure_keyword(self, keyword_id: int | None, keyword: str | None) -> int:
        if keyword_id is not None:
            existing = self.keyword_repository.get(keyword_id)
            if not existing:
                raise ValueError("Keyword not found.")
            if existing.status in {KeywordStatus.QUEUED, KeywordStatus.PROCESSING, KeywordStatus.COMPLETED}:
                raise ValueError(f"Keyword is already {existing.status.value}.")
            return keyword_id
        if not keyword:
            raise ValueError("Either keyword_id or keyword is required.")
        entry = self.keyword_repository.create(keyword=keyword)
        return entry.id

    def build_payload(self, keyword_id: int, payload, rule: AutomationRule | None) -> dict:
        return {
            "keyword_id": keyword_id,
            "website_ids": payload.website_ids or (rule.target_website_ids if rule else []),
            "word_count": payload.word_count or (rule.word_count if rule else self.settings.default_word_count),
            "inline_image_count": payload.inline_image_count
            or (rule.inline_image_count if rule else self.settings.default_inline_image_count),
            "featured_image_width": payload.featured_image_width
            or (rule.featured_image_width if rule else self.settings.default_featured_image_width),
            "featured_image_height": payload.featured_image_height
            or (rule.featured_image_height if rule else self.settings.default_featured_image_height),
            "post_status": payload.post_status or (rule.post_status if rule else self.settings.default_post_status),
            "similarity_check_enabled": rule.similarity_check_enabled if rule else self.settings.embedding_similarity_enabled,
            "similarity_threshold": rule.similarity_threshold if rule else self.settings.default_similarity_threshold,
            "scheduled_for": payload.scheduled_for.isoformat() if payload.scheduled_for else None,
            "triggered_at": datetime.utcnow().isoformat(),
        }

    def dispatch(self, task_payload: dict):
        keyword = self.keyword_repository.get(task_payload["keyword_id"])
        if keyword and keyword.status == KeywordStatus.PENDING:
            keyword.status = KeywordStatus.QUEUED
        return process_keyword_task.delay(task_payload)
