from __future__ import annotations

from datetime import datetime

from app.config import get_settings
from app.database.models import BlogPost, GeneratedImage, ImageKind, PublicationLog, PublicationStatus
from app.publisher.service import PublisherFactory
from app.repositories.publication_log_repository import PublicationLogRepository
from app.repositories.website_repository import WebsiteRepository


class PublicationService:
    def __init__(
        self,
        website_repository: WebsiteRepository,
        publication_log_repository: PublicationLogRepository,
    ) -> None:
        self.website_repository = website_repository
        self.publication_log_repository = publication_log_repository
        self.settings = get_settings()

    def publish(self, post: BlogPost, website_ids: list[int], inline_images: list[dict[str, str]]) -> None:
        if not website_ids:
            return

        featured_image = next((image for image in post.images if image.kind == ImageKind.FEATURED), None)
        for website in self.website_repository.list_active_by_ids(website_ids):
            log = self.publication_log_repository.add(
                PublicationLog(
                    blog_post_id=post.id,
                    website_id=website.id,
                    status=PublicationStatus.PENDING,
                    attempt_count=1,
                )
            )
            publisher = PublisherFactory.create(website)

            for attempt in range(1, self.settings.max_publish_retries + 1):
                log.attempt_count = attempt
                try:
                    response = publisher.publish(
                        {
                            "title": post.title,
                            "slug": post.slug,
                            "meta_title": post.meta_title,
                            "meta_description": post.meta_description,
                            "seo_keywords": post.seo_keywords,
                            "content_markdown": post.content_markdown,
                            "content_html": post.content_html,
                            "post_status": post.publish_status,
                            "featured_image_path": featured_image.storage_path if featured_image else None,
                            "featured_image_alt": featured_image.alt_text if featured_image else None,
                            "inline_images": inline_images,
                        }
                    )
                    log.status = PublicationStatus.SUCCESS
                    log.external_post_id = response.get("external_post_id")
                    log.external_url = response.get("external_url")
                    log.response_excerpt = response.get("response_excerpt")
                    log.published_at = datetime.utcnow()
                    break
                except Exception as exc:
                    log.status = PublicationStatus.FAILED
                    log.response_excerpt = str(exc)
