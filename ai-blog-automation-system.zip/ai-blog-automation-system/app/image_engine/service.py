from __future__ import annotations

import base64
from pathlib import Path
from uuid import uuid4

from app.ai_engine.client import get_openai_client
from app.config import get_settings


class ImageService:
    def __init__(self) -> None:
        self.settings = get_settings()
        self.client = get_openai_client()
        self.storage_dir = Path("generated_assets")
        self.storage_dir.mkdir(parents=True, exist_ok=True)

    def generate_image(self, prompt: str, width: int, height: int, alt_text: str) -> dict:
        size = self._normalize_size(width=width, height=height)
        response = self.client.images.generate(
            model=self.settings.openai_image_model,
            prompt=prompt,
            size=size,
        )
        payload = response.data[0]
        image_bytes = base64.b64decode(payload.b64_json)
        filename = f"{uuid4().hex}.png"
        file_path = self.storage_dir / filename
        file_path.write_bytes(image_bytes)
        return {
            "prompt": prompt,
            "alt_text": alt_text,
            "storage_path": str(file_path),
            "mime_type": "image/png",
            "width": int(size.split("x")[0]),
            "height": int(size.split("x")[1]),
            "source_url": None,
        }

    def _normalize_size(self, width: int, height: int) -> str:
        supported = {"1024x1024", "1024x1536", "1536x1024"}
        candidate = f"{width}x{height}"
        if candidate in supported:
            return candidate
        return "1536x1024" if width >= height else "1024x1536"
