from functools import lru_cache
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    app_name: str = "AI Blog Automation System"
    app_env: Literal["development", "staging", "production"] = "development"
    app_host: str = "0.0.0.0"
    app_port: int = 8000
    api_prefix: str = "/api/v1"
    secret_key: str = Field(default="change-me", min_length=8)
    log_level: str = "INFO"
    auto_create_tables: bool = True

    postgres_user: str = "postgres"
    postgres_password: str = "postgres"
    postgres_host: str = "postgres"
    postgres_port: int = 5432
    postgres_db: str = "ai_blog_automation"
    database_url: str | None = None

    redis_url: str = "redis://redis:6379/0"
    celery_broker_url: str | None = None
    celery_result_backend: str | None = None
    celery_timezone: str = "UTC"

    openai_api_key: str = ""
    openai_text_model: str = "gpt-5.4-mini"
    openai_image_model: str = "gpt-image-1.5"
    openai_embedding_model: str = "text-embedding-3-small"

    default_word_count: int = 1800
    default_inline_image_count: int = 2
    default_featured_image_width: int = 1536
    default_featured_image_height: int = 1024
    default_post_status: Literal["draft", "publish", "scheduled"] = "draft"
    default_similarity_threshold: float = 0.92
    embedding_similarity_enabled: bool = True
    request_timeout_seconds: int = 120
    max_publish_retries: int = 3

    scheduler_scan_minutes: int = 15
    scheduler_default_hour_utc: int = 8
    scheduler_default_minute_utc: int = 0

    @property
    def sqlalchemy_database_url(self) -> str:
        if self.database_url:
            return self.database_url
        return (
            f"postgresql+psycopg://{self.postgres_user}:{self.postgres_password}"
            f"@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"
        )

    @property
    def broker_url(self) -> str:
        return self.celery_broker_url or self.redis_url

    @property
    def result_backend(self) -> str:
        return self.celery_result_backend or self.redis_url


@lru_cache
def get_settings() -> Settings:
    return Settings()
