from celery import Celery

from app.config import get_settings


settings = get_settings()

celery_app = Celery(
    "ai_blog_automation",
    broker=settings.broker_url,
    backend=settings.result_backend,
)

celery_app.conf.update(
    task_track_started=True,
    timezone=settings.celery_timezone,
    broker_connection_retry_on_startup=True,
    beat_schedule={
        "scan-and-enqueue-keywords": {
            "task": "app.scheduler.tasks.enqueue_scheduled_jobs",
            "schedule": settings.scheduler_scan_minutes * 60,
        }
    },
)

celery_app.autodiscover_tasks(["app.scheduler"])
