from __future__ import annotations

from datetime import datetime

from celery.utils.log import get_task_logger

from app.application.dto import AutomationRequest
from app.application.workflow import BlogAutomationWorkflow
from app.celery_app import celery_app
from app.database.session import SessionLocal
from app.database.models import KeywordStatus, ScheduleFrequency
from app.repositories.automation_rule_repository import AutomationRuleRepository
from app.repositories.keyword_repository import KeywordRepository


logger = get_task_logger(__name__)


@celery_app.task(name="app.scheduler.tasks.process_keyword_task", bind=True, autoretry_for=(Exception,), retry_backoff=True)
def process_keyword_task(self, payload: dict) -> dict:
    db = SessionLocal()
    try:
        request = AutomationRequest(
            keyword_id=payload["keyword_id"],
            website_ids=payload.get("website_ids", []),
            word_count=payload["word_count"],
            inline_image_count=payload["inline_image_count"],
            featured_image_width=payload["featured_image_width"],
            featured_image_height=payload["featured_image_height"],
            post_status=payload["post_status"],
            similarity_check_enabled=payload["similarity_check_enabled"],
            similarity_threshold=payload["similarity_threshold"],
            scheduled_for=datetime.fromisoformat(payload["scheduled_for"]) if payload.get("scheduled_for") else None,
        )
        service = BlogAutomationWorkflow(db)
        post = service.process_keyword(request)
        return {"blog_post_id": post.id, "title": post.title}
    finally:
        db.close()


@celery_app.task(name="app.scheduler.tasks.enqueue_scheduled_jobs")
def enqueue_scheduled_jobs() -> dict:
    db = SessionLocal()
    queued = 0
    now = datetime.utcnow()
    weekday = now.strftime("%A").lower()

    try:
        rule_repository = AutomationRuleRepository(db)
        keyword_repository = KeywordRepository(db)
        rules = rule_repository.list_active()
        pending_keywords = keyword_repository.list_pending()
        if not pending_keywords:
            return {"queued": 0}

        for rule in rules:
            if rule.frequency == ScheduleFrequency.MANUAL:
                continue
            if rule.frequency == ScheduleFrequency.WEEKLY and weekday not in {day.lower() for day in rule.days_of_week}:
                continue
            if now.time() < rule.run_time_utc:
                continue

            keyword = pending_keywords.pop(0)
            keyword.status = KeywordStatus.QUEUED
            db.commit()
            process_keyword_task.delay(
                {
                    "keyword_id": keyword.id,
                    "website_ids": rule.target_website_ids,
                    "word_count": rule.word_count,
                    "inline_image_count": rule.inline_image_count,
                    "featured_image_width": rule.featured_image_width,
                    "featured_image_height": rule.featured_image_height,
                    "post_status": rule.post_status,
                    "similarity_check_enabled": rule.similarity_check_enabled,
                    "similarity_threshold": rule.similarity_threshold,
                    "scheduled_for": None,
                }
            )
            queued += 1
            if not pending_keywords:
                break

        logger.info("Queued %s keyword automation jobs.", queued)
        return {"queued": queued}
    finally:
        db.close()
