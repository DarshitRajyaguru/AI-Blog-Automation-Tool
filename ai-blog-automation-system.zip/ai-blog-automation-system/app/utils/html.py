from markdown import markdown


def markdown_to_html(content: str) -> str:
    return markdown(
        content,
        extensions=["extra", "fenced_code", "tables", "toc"],
        output_format="html5",
    )
