from __future__ import annotations

from abc import ABC, abstractmethod

from app.database.models import Website


class PublisherBase(ABC):
    def __init__(self, website: Website) -> None:
        self.website = website

    @abstractmethod
    def publish(self, payload: dict) -> dict:
        raise NotImplementedError
