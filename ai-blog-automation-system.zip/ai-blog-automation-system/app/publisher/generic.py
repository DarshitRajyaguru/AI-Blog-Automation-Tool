from __future__ import annotations

import requests
from requests.auth import HTTPBasicAuth

from app.database.models import AuthType
from app.publisher.base import PublisherBase


class GenericApiPublisher(PublisherBase):
    def publish(self, payload: dict) -> dict:
        if not self.website.api_endpoint:
            raise ValueError("Generic API publisher requires api_endpoint.")

        headers = {"Accept": "application/json", "Content-Type": "application/json"}
        headers.update(self.website.headers_json or {})
        if self.website.auth_type == AuthType.BEARER and self.website.token:
            headers["Authorization"] = f"Bearer {self.website.token}"

        response = requests.post(
            self.website.api_endpoint,
            json={
                "title": payload["title"],
                "slug": payload["slug"],
                "meta_title": payload["meta_title"],
                "meta_description": payload["meta_description"],
                "keywords": payload["seo_keywords"],
                "content_markdown": payload["content_markdown"],
                "content_html": payload["content_html"],
                "featured_image_path": payload.get("featured_image_path"),
                "inline_images": payload.get("inline_images", []),
                "post_status": payload["post_status"],
            },
            headers=headers,
            auth=self._auth(),
            timeout=60,
        )
        response.raise_for_status()
        data = response.json() if response.content else {}
        return {
            "external_post_id": str(data.get("id", "")),
            "external_url": data.get("url"),
            "response_excerpt": response.text[:1000],
        }

    def _auth(self) -> HTTPBasicAuth | None:
        if self.website.auth_type == AuthType.BASIC:
            if not self.website.username or not self.website.password:
                raise ValueError("Generic basic auth requires username and password.")
            return HTTPBasicAuth(self.website.username, self.website.password)
        return None
