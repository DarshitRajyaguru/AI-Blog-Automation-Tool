from app.database.models import Website, WebsiteType
from app.publisher.generic import GenericApiPublisher
from app.publisher.wordpress import WordPressPublisher


class PublisherFactory:
    @staticmethod
    def create(website: Website):
        if website.website_type == WebsiteType.WORDPRESS:
            return WordPressPublisher(website)
        if website.website_type == WebsiteType.GENERIC_API:
            return GenericApiPublisher(website)
        raise ValueError(f"Unsupported website type: {website.website_type}")
