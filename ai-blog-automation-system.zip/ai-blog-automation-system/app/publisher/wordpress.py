from __future__ import annotations

from pathlib import Path

import requests
from requests.auth import HTTPBasicAuth

from app.database.models import AuthType, Website
from app.publisher.base import PublisherBase


class WordPressPublisher(PublisherBase):
    def __init__(self, website: Website) -> None:
        super().__init__(website)
        self.timeout = 60

    def publish(self, payload: dict) -> dict:
        featured_media_id = None
        content_html = payload["content_html"]
        if payload.get("featured_image_path"):
            featured_media = self._upload_media(payload["featured_image_path"], payload.get("featured_image_alt", ""))
            featured_media_id = featured_media["id"]

        for inline_image in payload.get("inline_images", []):
            uploaded = self._upload_media(inline_image["storage_path"], inline_image["alt_text"])
            content_html = content_html.replace(inline_image["storage_path"], uploaded["url"])

        body = {
            "title": payload["title"],
            "slug": payload["slug"],
            "status": payload["post_status"],
            "content": content_html,
            "excerpt": payload["meta_description"],
        }
        if featured_media_id is not None:
            body["featured_media"] = featured_media_id

        post_url = f"{self.website.base_url.rstrip('/')}/wp-json/wp/v2/posts"
        response = requests.post(
            post_url,
            json=body,
            headers=self._headers(),
            auth=self._auth(),
            timeout=self.timeout,
        )
        response.raise_for_status()
        data = response.json()
        return {
            "external_post_id": str(data.get("id")),
            "external_url": data.get("link"),
            "response_excerpt": response.text[:1000],
        }

    def _upload_media(self, file_path: str, alt_text: str) -> dict:
        path = Path(file_path)
        media_url = self.website.media_endpoint or f"{self.website.base_url.rstrip('/')}/wp-json/wp/v2/media"
        headers = self._headers()
        headers["Content-Disposition"] = f'attachment; filename="{path.name}"'
        headers["Content-Type"] = "image/png"

        response = requests.post(
            media_url,
            data=path.read_bytes(),
            headers=headers,
            auth=self._auth(),
            timeout=self.timeout,
        )
        response.raise_for_status()
        media = response.json()

        if alt_text:
            requests.post(
                f"{media_url.rstrip('/')}/{media['id']}",
                json={"alt_text": alt_text},
                headers=self._headers(),
                auth=self._auth(),
                timeout=self.timeout,
            )
        return {"id": int(media["id"]), "url": media.get("source_url")}

    def _headers(self) -> dict:
        headers = {"Accept": "application/json"}
        headers.update(self.website.headers_json or {})
        if self.website.auth_type == AuthType.BEARER and self.website.token:
            headers["Authorization"] = f"Bearer {self.website.token}"
        return headers

    def _auth(self) -> HTTPBasicAuth | None:
        if self.website.auth_type in {AuthType.BASIC, AuthType.WORDPRESS_APP_PASSWORD}:
            if not self.website.username or not self.website.password:
                raise ValueError("WordPress username and password are required.")
            return HTTPBasicAuth(self.website.username, self.website.password)
        return None
