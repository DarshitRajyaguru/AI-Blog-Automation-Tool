from __future__ import annotations

import json

from app.ai_engine.client import get_openai_client
from app.ai_engine.schemas import BlogGenerationResult
from app.config import get_settings


class AIContentService:
    def __init__(self) -> None:
        self.settings = get_settings()
        self.client = get_openai_client()

    def generate_blog(self, keyword: str, word_count: int) -> BlogGenerationResult:
        schema = BlogGenerationResult.model_json_schema()
        prompt = (
            "Generate an SEO-optimized long-form blog article in JSON only. "
            f"Primary keyword: {keyword}. Target word count: {word_count}. "
            "Requirements: natural keyword density, human tone, one H1, multiple H2/H3 sections, "
            "FAQ section, meta title, meta description, slug, and 3 internal linking placeholders. "
            "The content_markdown field must include the complete article with markdown headings and conclude with FAQs."
        )

        response = self.client.responses.create(
            model=self.settings.openai_text_model,
            input=[
                {
                    "role": "system",
                    "content": (
                        "You are an expert SEO editor and blog strategist. "
                        "Return only valid JSON that matches the provided schema."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            text={
                "format": {
                    "type": "json_schema",
                    "name": "blog_generation_result",
                    "schema": schema,
                }
            },
        )
        return BlogGenerationResult.model_validate(json.loads(response.output_text))

    def generate_embedding(self, text: str) -> list[float]:
        response = self.client.embeddings.create(
            model=self.settings.openai_embedding_model,
            input=text,
            encoding_format="float",
        )
        return list(response.data[0].embedding)
