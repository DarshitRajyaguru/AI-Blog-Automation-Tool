from pydantic import BaseModel, Field


class HeadingBlock(BaseModel):
    level: str = Field(pattern="^H[1-3]$")
    title: str
    content: str


class FAQItem(BaseModel):
    question: str
    answer: str


class BlogGenerationResult(BaseModel):
    title: str
    slug: str
    meta_title: str
    meta_description: str
    keywords: list[str]
    headings: list[HeadingBlock]
    faq: list[FAQItem]
    internal_link_placeholders: list[str]
    content_markdown: str
