from __future__ import annotations

import re

from app.ai_engine.schemas import BlogGenerationResult
from app.utils.text import readability_score


class SEOService:
    def enhance(self, blog: BlogGenerationResult) -> dict:
        heading_levels = [heading.level for heading in blog.headings]
        keyword_list = list(dict.fromkeys(blog.keywords + self._extract_keywords(blog.content_markdown)))
        return {
            "meta_title": blog.meta_title[:60],
            "meta_description": blog.meta_description[:160],
            "keywords": keyword_list[:10],
            "heading_levels": heading_levels,
            "readability_score": readability_score(blog.content_markdown),
            "internal_link_placeholders": blog.internal_link_placeholders,
        }

    def _extract_keywords(self, content: str) -> list[str]:
        words = re.findall(r"\b[a-zA-Z][a-zA-Z0-9-]{3,}\b", content.lower())
        frequencies: dict[str, int] = {}
        for word in words:
            frequencies[word] = frequencies.get(word, 0) + 1
        return [word for word, _count in sorted(frequencies.items(), key=lambda item: item[1], reverse=True)[:10]]
