from fastapi import APIRouter

from app.api.routes import automation, health, keywords, logs, websites


api_router = APIRouter()
api_router.include_router(health.router, tags=["health"])
api_router.include_router(keywords.router, prefix="/keywords", tags=["keywords"])
api_router.include_router(websites.router, prefix="/websites", tags=["websites"])
api_router.include_router(automation.router, prefix="/automation", tags=["automation"])
api_router.include_router(logs.router, prefix="/logs", tags=["logs"])
