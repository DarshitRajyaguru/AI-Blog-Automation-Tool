from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.application.automation_dispatcher import AutomationDispatcher
from app.api.dependencies import db_dependency
from app.schemas import AutomationRuleCreate, AutomationRunResponse, AutomationTriggerRequest
from app.database.models import AutomationRule
from app.repositories.automation_rule_repository import AutomationRuleRepository
from app.repositories.keyword_repository import KeywordRepository


router = APIRouter()


@router.post("/rules", status_code=status.HTTP_201_CREATED)
def create_rule(payload: AutomationRuleCreate, db: Session = Depends(db_dependency)) -> dict:
    rule_repository = AutomationRuleRepository(db)
    rule = rule_repository.create(AutomationRule(**payload.model_dump()))
    db.commit()
    db.refresh(rule)
    return {"id": rule.id, "name": rule.name}


@router.post("/run", response_model=AutomationRunResponse, status_code=status.HTTP_202_ACCEPTED)
def trigger_automation(payload: AutomationTriggerRequest, db: Session = Depends(db_dependency)) -> AutomationRunResponse:
    keyword_repository = KeywordRepository(db)
    rule_repository = AutomationRuleRepository(db)
    dispatcher = AutomationDispatcher(keyword_repository)

    try:
        keyword_id = dispatcher.ensure_keyword(payload.keyword_id, payload.keyword)
        db.commit()
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(exc))

    if not keyword_repository.get(keyword_id):
        raise HTTPException(status_code=404, detail="Keyword not found.")

    rule = rule_repository.get(payload.rule_id) if payload.rule_id else None
    task = dispatcher.dispatch(dispatcher.build_payload(keyword_id, payload, rule))
    db.commit()
    return AutomationRunResponse(task_id=task.id, message="Automation job queued.")
