from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.api.dependencies import db_dependency
from app.database.models import Website
from app.schemas import WebsiteCreate, WebsiteRead, WebsiteUpdate
from app.repositories.website_repository import WebsiteRepository


router = APIRouter()


@router.post("", response_model=WebsiteRead, status_code=status.HTTP_201_CREATED)
def create_website(payload: WebsiteCreate, db: Session = Depends(db_dependency)) -> WebsiteRead:
    website = Website(**payload.model_dump())
    website.base_url = str(payload.base_url)
    website.api_endpoint = str(payload.api_endpoint) if payload.api_endpoint else None
    website.media_endpoint = str(payload.media_endpoint) if payload.media_endpoint else None
    db.add(website)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Website with this name already exists.")
    db.refresh(website)
    return WebsiteRead.model_validate(website)


@router.get("", response_model=list[WebsiteRead])
def list_websites(db: Session = Depends(db_dependency)) -> list[WebsiteRead]:
    websites = WebsiteRepository(db).list_all()
    return [WebsiteRead.model_validate(website) for website in websites]


@router.put("/{website_id}", response_model=WebsiteRead)
def update_website(website_id: int, payload: WebsiteUpdate, db: Session = Depends(db_dependency)) -> WebsiteRead:
    repository = WebsiteRepository(db)
    website = repository.get(website_id)
    if not website:
        raise HTTPException(status_code=404, detail="Website not found.")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(website, field, str(value) if field in {"api_endpoint", "media_endpoint"} and value else value)
    db.commit()
    db.refresh(website)
    return WebsiteRead.model_validate(website)
