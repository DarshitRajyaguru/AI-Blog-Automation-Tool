from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.api.dependencies import db_dependency
from app.schemas import KeywordCreate, KeywordRead
from app.repositories.keyword_repository import KeywordRepository


router = APIRouter()


@router.post("", response_model=KeywordRead, status_code=status.HTTP_201_CREATED)
def add_keyword(payload: KeywordCreate, db: Session = Depends(db_dependency)) -> KeywordRead:
    repository = KeywordRepository(db)
    keyword = repository.create(payload.keyword, priority=payload.priority, notes=payload.notes)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Keyword already exists.")
    db.refresh(keyword)
    return KeywordRead.model_validate(keyword)


@router.get("", response_model=list[KeywordRead])
def list_keywords(db: Session = Depends(db_dependency)) -> list[KeywordRead]:
    keywords = KeywordRepository(db).list_all()
    return [KeywordRead.model_validate(keyword) for keyword in keywords]
