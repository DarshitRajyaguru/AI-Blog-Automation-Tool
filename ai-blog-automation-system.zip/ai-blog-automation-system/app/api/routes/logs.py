from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.dependencies import db_dependency
from app.schemas import PublicationLogRead
from app.repositories.job_repository import JobRepository
from app.repositories.publication_log_repository import PublicationLogRepository


router = APIRouter()


@router.get("/publication", response_model=list[PublicationLogRead])
def publication_logs(db: Session = Depends(db_dependency)) -> list[PublicationLogRead]:
    logs = PublicationLogRepository(db).list_recent()
    return [PublicationLogRead.model_validate(log) for log in logs]


@router.get("/automation")
def automation_logs(db: Session = Depends(db_dependency)) -> list[dict]:
    jobs = JobRepository(db).list_recent()
    return [
        {
            "id": job.id,
            "rule_id": job.rule_id,
            "keyword_id": job.keyword_id,
            "blog_post_id": job.blog_post_id,
            "status": job.status,
            "message": job.message,
            "started_at": job.started_at,
            "finished_at": job.finished_at,
            "created_at": job.created_at,
        }
        for job in jobs
    ]
