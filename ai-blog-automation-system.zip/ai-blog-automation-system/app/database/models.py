from __future__ import annotations

from datetime import datetime, time
from enum import Enum

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Enum as SqlEnum,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
        nullable=False,
    )


class WebsiteType(str, Enum):
    WORDPRESS = "wordpress"
    GENERIC_API = "generic_api"


class AuthType(str, Enum):
    NONE = "none"
    BASIC = "basic"
    BEARER = "bearer"
    WORDPRESS_APP_PASSWORD = "wordpress_app_password"


class KeywordStatus(str, Enum):
    PENDING = "pending"
    QUEUED = "queued"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class PostLifecycleStatus(str, Enum):
    GENERATED = "generated"
    PUBLISHED = "published"
    FAILED = "failed"
    SCHEDULED = "scheduled"


class PublicationStatus(str, Enum):
    PENDING = "pending"
    SUCCESS = "success"
    FAILED = "failed"


class ScheduleFrequency(str, Enum):
    MANUAL = "manual"
    DAILY = "daily"
    WEEKLY = "weekly"


class AutomationJobStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"


class ImageKind(str, Enum):
    FEATURED = "featured"
    INLINE = "inline"


class Website(TimestampMixin, Base):
    __tablename__ = "websites"
    __table_args__ = (Index("ix_websites_is_active", "is_active"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    website_type: Mapped[WebsiteType] = mapped_column(SqlEnum(WebsiteType), nullable=False)
    base_url: Mapped[str] = mapped_column(String(512), nullable=False)
    auth_type: Mapped[AuthType] = mapped_column(SqlEnum(AuthType), default=AuthType.NONE, nullable=False)
    username: Mapped[str | None] = mapped_column(String(255))
    password: Mapped[str | None] = mapped_column(String(255))
    token: Mapped[str | None] = mapped_column(Text)
    api_endpoint: Mapped[str | None] = mapped_column(String(512))
    media_endpoint: Mapped[str | None] = mapped_column(String(512))
    headers_json: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    publication_logs: Mapped[list["PublicationLog"]] = relationship(back_populates="website")


class KeywordEntry(TimestampMixin, Base):
    __tablename__ = "keyword_entries"
    __table_args__ = (
        UniqueConstraint("normalized_keyword", name="uq_keyword_entries_normalized_keyword"),
        Index("ix_keyword_entries_status_priority", "status", "priority"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    keyword: Mapped[str] = mapped_column(String(255), nullable=False)
    normalized_keyword: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[KeywordStatus] = mapped_column(SqlEnum(KeywordStatus), default=KeywordStatus.PENDING, nullable=False)
    priority: Mapped[int] = mapped_column(Integer, default=100, nullable=False)
    notes: Mapped[str | None] = mapped_column(Text)
    last_processed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    posts: Mapped[list["BlogPost"]] = relationship(back_populates="keyword")


class AutomationRule(TimestampMixin, Base):
    __tablename__ = "automation_rules"
    __table_args__ = (
        Index("ix_automation_rules_is_active_frequency", "is_active", "frequency"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    frequency: Mapped[ScheduleFrequency] = mapped_column(SqlEnum(ScheduleFrequency), default=ScheduleFrequency.DAILY)
    days_of_week: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)
    run_time_utc: Mapped[time] = mapped_column(default=time(hour=8, minute=0), nullable=False)
    timezone: Mapped[str] = mapped_column(String(64), default="UTC", nullable=False)
    target_website_ids: Mapped[list[int]] = mapped_column(JSON, default=list, nullable=False)
    word_count: Mapped[int] = mapped_column(Integer, default=1800, nullable=False)
    inline_image_count: Mapped[int] = mapped_column(Integer, default=2, nullable=False)
    featured_image_width: Mapped[int] = mapped_column(Integer, default=1536, nullable=False)
    featured_image_height: Mapped[int] = mapped_column(Integer, default=1024, nullable=False)
    post_status: Mapped[str] = mapped_column(String(32), default="draft", nullable=False)
    similarity_check_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    similarity_threshold: Mapped[float] = mapped_column(default=0.92, nullable=False)

    jobs: Mapped[list["AutomationJob"]] = relationship(back_populates="rule")


class BlogPost(TimestampMixin, Base):
    __tablename__ = "blog_posts"
    __table_args__ = (
        UniqueConstraint("slug", name="uq_blog_posts_slug"),
        UniqueConstraint("content_hash", name="uq_blog_posts_content_hash"),
        Index("ix_blog_posts_keyword_id", "keyword_id"),
        Index("ix_blog_posts_lifecycle_status", "lifecycle_status"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    keyword_id: Mapped[int] = mapped_column(ForeignKey("keyword_entries.id"), nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    slug: Mapped[str] = mapped_column(String(255), nullable=False)
    meta_title: Mapped[str] = mapped_column(String(255), nullable=False)
    meta_description: Mapped[str] = mapped_column(String(320), nullable=False)
    seo_keywords: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)
    content_markdown: Mapped[str] = mapped_column(Text, nullable=False)
    content_html: Mapped[str] = mapped_column(Text, nullable=False)
    faq_items: Mapped[list[dict]] = mapped_column(JSON, default=list, nullable=False)
    outlines: Mapped[list[dict]] = mapped_column(JSON, default=list, nullable=False)
    content_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    content_embedding: Mapped[list[float] | None] = mapped_column(JSON)
    readability_score: Mapped[float | None] = mapped_column()
    lifecycle_status: Mapped[PostLifecycleStatus] = mapped_column(
        SqlEnum(PostLifecycleStatus),
        default=PostLifecycleStatus.GENERATED,
        nullable=False,
    )
    publish_status: Mapped[str] = mapped_column(String(32), default="draft", nullable=False)
    scheduled_for: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    keyword: Mapped["KeywordEntry"] = relationship(back_populates="posts")
    images: Mapped[list["GeneratedImage"]] = relationship(back_populates="post", cascade="all, delete-orphan")
    publication_logs: Mapped[list["PublicationLog"]] = relationship(back_populates="post", cascade="all, delete-orphan")


class GeneratedImage(TimestampMixin, Base):
    __tablename__ = "generated_images"
    __table_args__ = (Index("ix_generated_images_blog_post_kind", "blog_post_id", "kind"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    blog_post_id: Mapped[int] = mapped_column(ForeignKey("blog_posts.id"), nullable=False)
    kind: Mapped[ImageKind] = mapped_column(SqlEnum(ImageKind), nullable=False)
    prompt: Mapped[str] = mapped_column(Text, nullable=False)
    alt_text: Mapped[str] = mapped_column(String(255), nullable=False)
    source_url: Mapped[str | None] = mapped_column(String(1024))
    storage_path: Mapped[str | None] = mapped_column(String(1024))
    mime_type: Mapped[str] = mapped_column(String(100), default="image/png", nullable=False)
    width: Mapped[int] = mapped_column(Integer, nullable=False)
    height: Mapped[int] = mapped_column(Integer, nullable=False)
    position_index: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    post: Mapped["BlogPost"] = relationship(back_populates="images")


class PublicationLog(TimestampMixin, Base):
    __tablename__ = "publication_logs"
    __table_args__ = (
        Index("ix_publication_logs_blog_post_website", "blog_post_id", "website_id"),
        Index("ix_publication_logs_status", "status"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    blog_post_id: Mapped[int] = mapped_column(ForeignKey("blog_posts.id"), nullable=False)
    website_id: Mapped[int] = mapped_column(ForeignKey("websites.id"), nullable=False)
    status: Mapped[PublicationStatus] = mapped_column(SqlEnum(PublicationStatus), default=PublicationStatus.PENDING)
    external_post_id: Mapped[str | None] = mapped_column(String(255))
    external_url: Mapped[str | None] = mapped_column(String(1024))
    response_excerpt: Mapped[str | None] = mapped_column(Text)
    attempt_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    post: Mapped["BlogPost"] = relationship(back_populates="publication_logs")
    website: Mapped["Website"] = relationship(back_populates="publication_logs")


class AutomationJob(TimestampMixin, Base):
    __tablename__ = "automation_jobs"
    __table_args__ = (
        Index("ix_automation_jobs_status_created_at", "status", "created_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    rule_id: Mapped[int | None] = mapped_column(ForeignKey("automation_rules.id"))
    keyword_id: Mapped[int | None] = mapped_column(ForeignKey("keyword_entries.id"))
    blog_post_id: Mapped[int | None] = mapped_column(ForeignKey("blog_posts.id"))
    status: Mapped[AutomationJobStatus] = mapped_column(SqlEnum(AutomationJobStatus), default=AutomationJobStatus.PENDING)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    message: Mapped[str | None] = mapped_column(Text)

    rule: Mapped["AutomationRule"] = relationship(back_populates="jobs")
