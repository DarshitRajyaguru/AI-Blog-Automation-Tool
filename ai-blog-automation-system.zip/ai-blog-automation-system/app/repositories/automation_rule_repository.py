from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import AutomationRule


class AutomationRuleRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, rule: AutomationRule) -> AutomationRule:
        self.db.add(rule)
        self.db.flush()
        return rule

    def get(self, rule_id: int) -> AutomationRule | None:
        return self.db.get(AutomationRule, rule_id)

    def list_active(self) -> list[AutomationRule]:
        return self.db.scalars(select(AutomationRule).where(AutomationRule.is_active.is_(True))).all()
