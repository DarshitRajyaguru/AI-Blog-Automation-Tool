from __future__ import annotations

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import AutomationJob, AutomationJobStatus


class JobRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create_running_job(self, keyword_id: int) -> AutomationJob:
        job = AutomationJob(
            keyword_id=keyword_id,
            status=AutomationJobStatus.RUNNING,
            started_at=datetime.utcnow(),
            message="Started blog automation pipeline.",
        )
        self.db.add(job)
        self.db.flush()
        return job

    def list_recent(self, limit: int = 100) -> list[AutomationJob]:
        return self.db.scalars(select(AutomationJob).order_by(AutomationJob.created_at.desc()).limit(limit)).all()
