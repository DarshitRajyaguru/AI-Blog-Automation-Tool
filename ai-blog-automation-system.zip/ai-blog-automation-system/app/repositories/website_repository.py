from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import Website


class WebsiteRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get(self, website_id: int) -> Website | None:
        return self.db.get(Website, website_id)

    def list_all(self) -> list[Website]:
        return self.db.scalars(select(Website).order_by(Website.created_at.desc())).all()

    def list_active_by_ids(self, website_ids: list[int]) -> list[Website]:
        if not website_ids:
            return []
        return self.db.scalars(
            select(Website).where(Website.id.in_(website_ids), Website.is_active.is_(True))
        ).all()
