from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import PublicationLog


class PublicationLogRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def add(self, log: PublicationLog) -> PublicationLog:
        self.db.add(log)
        self.db.flush()
        return log

    def list_recent(self, limit: int = 100) -> list[PublicationLog]:
        return self.db.scalars(select(PublicationLog).order_by(PublicationLog.created_at.desc()).limit(limit)).all()
