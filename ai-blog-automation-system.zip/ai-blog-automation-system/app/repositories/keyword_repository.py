from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import KeywordEntry, KeywordStatus
from app.utils.text import normalize_keyword


class KeywordRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, keyword: str, priority: int = 100, notes: str | None = None) -> KeywordEntry:
        entry = KeywordEntry(
            keyword=keyword.strip(),
            normalized_keyword=normalize_keyword(keyword),
            priority=priority,
            notes=notes,
        )
        self.db.add(entry)
        self.db.flush()
        return entry

    def get(self, keyword_id: int) -> KeywordEntry | None:
        return self.db.get(KeywordEntry, keyword_id)

    def list_all(self) -> list[KeywordEntry]:
        return self.db.scalars(
            select(KeywordEntry).order_by(KeywordEntry.priority.asc(), KeywordEntry.created_at.asc())
        ).all()

    def list_pending(self) -> list[KeywordEntry]:
        return self.db.scalars(
            select(KeywordEntry).where(KeywordEntry.status == KeywordStatus.PENDING).order_by(KeywordEntry.priority.asc())
        ).all()

    def normalized_keyword_completed_exists(self, keyword: str, excluding_id: int | None = None) -> bool:
        statement = select(KeywordEntry).where(
            KeywordEntry.normalized_keyword == normalize_keyword(keyword),
            KeywordEntry.status == KeywordStatus.COMPLETED,
        )
        if excluding_id is not None:
            statement = statement.where(KeywordEntry.id != excluding_id)
        return self.db.scalar(statement) is not None
