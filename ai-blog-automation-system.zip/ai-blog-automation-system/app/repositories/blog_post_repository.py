from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.database.models import BlogPost


class BlogPostRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def add(self, post: BlogPost) -> BlogPost:
        self.db.add(post)
        self.db.flush()
        return post

    def get_with_assets(self, post_id: int) -> BlogPost | None:
        return self.db.scalar(
            select(BlogPost)
            .options(
                selectinload(BlogPost.images),
                selectinload(BlogPost.publication_logs),
            )
            .where(BlogPost.id == post_id)
        )

    def content_hash_exists(self, content_hash: str) -> bool:
        return self.db.scalar(select(BlogPost).where(BlogPost.content_hash == content_hash)) is not None

    def posts_with_embeddings(self) -> list[BlogPost]:
        return self.db.scalars(select(BlogPost).where(BlogPost.content_embedding.is_not(None))).all()
