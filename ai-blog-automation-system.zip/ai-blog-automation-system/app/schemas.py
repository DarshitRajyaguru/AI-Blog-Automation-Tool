from __future__ import annotations

from datetime import datetime, time
from typing import Any

from pydantic import BaseModel, Field, HttpUrl

from app.database.models import AuthType, PublicationStatus, ScheduleFrequency, WebsiteType


class KeywordCreate(BaseModel):
    keyword: str = Field(min_length=2, max_length=255)
    priority: int = 100
    notes: str | None = None


class KeywordRead(BaseModel):
    id: int
    keyword: str
    status: str
    priority: int
    notes: str | None
    created_at: datetime

    model_config = {"from_attributes": True}


class WebsiteCreate(BaseModel):
    name: str
    website_type: WebsiteType
    base_url: HttpUrl
    auth_type: AuthType = AuthType.NONE
    username: str | None = None
    password: str | None = None
    token: str | None = None
    api_endpoint: HttpUrl | None = None
    media_endpoint: HttpUrl | None = None
    headers_json: dict[str, Any] = Field(default_factory=dict)
    is_active: bool = True


class WebsiteUpdate(BaseModel):
    name: str | None = None
    auth_type: AuthType | None = None
    username: str | None = None
    password: str | None = None
    token: str | None = None
    api_endpoint: HttpUrl | None = None
    media_endpoint: HttpUrl | None = None
    headers_json: dict[str, Any] | None = None
    is_active: bool | None = None


class WebsiteRead(BaseModel):
    id: int
    name: str
    website_type: WebsiteType
    base_url: str
    auth_type: AuthType
    api_endpoint: str | None
    media_endpoint: str | None
    headers_json: dict[str, Any]
    is_active: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class AutomationRuleCreate(BaseModel):
    name: str
    frequency: ScheduleFrequency = ScheduleFrequency.DAILY
    days_of_week: list[str] = Field(default_factory=list)
    run_time_utc: time = time(hour=8, minute=0)
    timezone: str = "UTC"
    target_website_ids: list[int] = Field(default_factory=list)
    word_count: int = 1800
    inline_image_count: int = 2
    featured_image_width: int = 1536
    featured_image_height: int = 1024
    post_status: str = "draft"
    similarity_check_enabled: bool = True
    similarity_threshold: float = 0.92


class AutomationTriggerRequest(BaseModel):
    keyword_id: int | None = None
    keyword: str | None = None
    website_ids: list[int] = Field(default_factory=list)
    rule_id: int | None = None
    word_count: int | None = None
    inline_image_count: int | None = None
    featured_image_width: int | None = None
    featured_image_height: int | None = None
    post_status: str | None = None
    scheduled_for: datetime | None = None


class AutomationRunResponse(BaseModel):
    task_id: str
    message: str


class PublicationLogRead(BaseModel):
    id: int
    blog_post_id: int
    website_id: int
    status: PublicationStatus
    external_post_id: str | None
    external_url: str | None
    response_excerpt: str | None
    attempt_count: int
    created_at: datetime

    model_config = {"from_attributes": True}


class HealthResponse(BaseModel):
    status: str
